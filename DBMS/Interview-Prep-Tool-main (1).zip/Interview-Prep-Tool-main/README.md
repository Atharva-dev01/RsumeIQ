# AI Interview Preparation System

A comprehensive AI-powered interview preparation platform built with Streamlit, MySQL, and Groq AI.

## Features
-  AI-powered interview question generation
-  Real-time answer evaluation and feedback  
-  User authentication and profile management
-  Practice history tracking
-  Multiple topics and difficulty levels

## Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Set up MySQL database
3. Configure environment variables in `.env`
4. Run: `streamlit run main.py`

#Create the .env file and add this in it
# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=interview_prep

#for GROQ API KEY
# Groq AI Configuration - Get free API key from https://console.groq.com
GROQ_API_KEY=your_groq_api_key_here
AI_PROVIDER=groq
GROQ_MODEL=llama3-8b-8192

#Commands to Run the Project 

1. cd ai-interview-prep
2. python -m venv interview_env
3. interview_env\Scripts\activate
4. pip install -r requirements.txt
5. streamlit run main.py

#Database Setup 
# Login to MySQL
mysql -u root -p

# Then run these SQL commands:
CREATE DATABASE interview_prep;
USE interview_prep;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    difficulty VARCHAR(50) NOT NULL,
    question TEXT NOT NULL,
    user_answer TEXT NOT NULL,
    ai_feedback TEXT NOT NULL,
    ideal_answer TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
);

EXIT;
